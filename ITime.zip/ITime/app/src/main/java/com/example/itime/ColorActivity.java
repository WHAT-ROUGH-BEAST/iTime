package com.example.itime;

import androidx.appcompat.app.AppCompatActivity;

public class ColorActivity extends AppCompatActivity {
}
